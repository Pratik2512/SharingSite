// let div= document.getElementsByClassName("col")
// // const dav = document.querySelector("col");
// const dav = document.getElementsByClassName("col");

// // dav.onClick(target="window.location='#java.html'")

// div.onClick(target="window.location.href='https://www.facebook.com'");

// dav.addEventListener('click', function(){
//     window.location='https://www.facebook.com';
// });

document.addEventListener('DOMContentLoaded', function() {
    const clickableDiv1 = document.getElementById('col1');
    const clickableDiv2 = document.getElementById('col2');
    const clickableDiv3 = document.getElementById('col3');

    clickableDiv1.addEventListener('click', function() {
        // Redirect to the desired URL
        window.location = 'java.html';
    });
    clickableDiv2.addEventListener('click', function() {
        // Redirect to the desired URL
        window.location = 'os.html';
    });
    clickableDiv3.addEventListener('click', function() {
        // Redirect to the desired URL
        window.location = 'r.html';
    });
});